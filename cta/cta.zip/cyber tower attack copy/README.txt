read this file in order to run this game
firstly the linux tortoel
1.open cyber tower attack copy in the termianl
	you can ether right click in the folder and open in terminal
	or you can open you teminal on you desktop and use the cd comand to navaget to the game but note for the folder name of this file put the name  in  qoutes ''
2.run ./main
3(optioal).you may have to enter your pass word this is becuse it installs python and pygame

now windows tortoral
1.go online and find a python install totoral for windows
2.open cyber tower attack copy in cmd
	 you can open you teminal on you desktop and use the cd comand to navaget to the game but note for the folder name of this file put the name  in  qoutes ''
3. navagate to the trybiuld file
4.run python3 main.py
	
