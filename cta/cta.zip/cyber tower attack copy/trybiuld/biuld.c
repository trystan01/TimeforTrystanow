#include <stdlib.h>
int main(){
system("sudo apt install python3");
system("sudo apt install python3-pygame");
system("clear");
system("python3 trybiuld/main.py");
}
