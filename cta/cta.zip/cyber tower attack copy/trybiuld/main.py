import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
import pygame,random,sys,math,time
from pygame.locals import *
from pygame import mixer
mixer.init()
pygame.init()
global sectime
sectime=0
global money
money=200
global pepole
pepole=[]
global towers
towers=[]
global cpu_lives
cpu_lives=20
win=pygame.display.set_mode((900,700))
pygame.display.set_caption('cyber tower atack')
clock=pygame.time.Clock()
Grid=[['#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#'],
    ['!', '$', '$', '$', '$', '$', '$', '$', '$', '$', '$', '$', '$', '#'],
    ['#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '$', '#'],
    ['#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '$', '#'],
    ['#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '$', '#'],
    ['#', '$', '$', '$', '$', '$', '$', '$', '$', '$', '#', '#', '$', '#'],
    ['#', '$', '#', '#', '#', '#', '#', '#', '#', '$', '#', '#', '$', '#'],
    ['#', '$', '#', '#', '#', '#', '#', '#', '#', '$', '#', '#', '$', '#'],
    ['#', '$', '$', '$', '$', '$', '$', '$', '#', '$', '#', '#', '$', '#'],
    ['#', '#', '#', '#', '#', '#', '#', '$', '#', '$', '#', '#', '$', '#'],
    ['#', '#', '#', '#', '#', '#', '#', '$', '#', '$', '#', '#', '$', '#'],
    ['@', '$', '$', '$', '#', '#', '#', '$', '#', '$', '#', '#', '$', '#'],
    ['#', '#', '#', '$', '$', '$', '$', '$', '#', '$', '$', '$', '$', '#'],
    ['#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#']]

#pics
fireshotp=pygame.image.load('fireshotp.png')
virusscanp=pygame.image.load('virusscanp.png')
mrblobp=pygame.image.load('mrblobp.png')
trojanp=pygame.image.load('trojanp.png')
damagedp=pygame.image.load('damage.png')
skidyp=pygame.image.load('skidyp.png')
aroww=pygame.image.load('aroww.png')
#classes
class fireshot:
    def __init__(self,x,y):
        self.setcooldown=3
        self.curcooldown=0
        self.ondown=False
        self.damage=10
        self.x=x
        self.y=y
        self.atacklist=[]
        self.attacklist()
        
    def attacklist(self):
        x=int(self.x/50)
        y=int(self.y/50)
        if Grid[y-1][x]=='$':
            self.atacklist.append((x,y-1))
        if Grid[y+1][x]=='$':
            self.atacklist.append((x,y+1))
        if Grid[y][x-1]=='$':
            self.atacklist.append((x-1,y))
        if Grid[y][x+1]=='$':
            self.atacklist.append((x+1,y))
    def draw(self):
        win.blit(fireshotp,(self.x,self.y))
    def scan(self):
        if len(pepole)>0:
            for per in pepole:
                if (int(per.x/50),int(per.y/50)) in self.atacklist:
                    if per.vis:
                        if not self.ondown:
                            per.damage()
                            self.ondown=True
    def cooldown(self):
        if self.ondown:
            if self.curcooldown==self.setcooldown:
                self.ondown=False
                self.curcooldown=0
            else:
                self.curcooldown+=1

class virusscan:
    def __init__(self,x,y):
        self.setcooldown=7
        self.curcooldown=0
        self.ondown=False
        self.damage=10
        self.x=x
        self.y=y
        self.atacklist=[]
        self.attacklist()
        
    def attacklist(self):
        x=int(self.x/50)
        y=int(self.y/50)
        if Grid[y-1][x]=='$':
            self.atacklist.append((x,y-1))
        if Grid[y+1][x]=='$':
            self.atacklist.append((x,y+1))
        if Grid[y][x-1]=='$':
            self.atacklist.append((x-1,y))
        if Grid[y][x+1]=='$':
            self.atacklist.append((x+1,y))
    def draw(self):
        win.blit(fireshotp,(self.x,self.y))
    def scan(self):
        if len(pepole)>0:
            for per in pepole:
                if (int(per.x/50),int(per.y/50)) in self.atacklist:
                    if not self.ondown:
                        per.damage()
                        self.ondown=True
    def cooldown(self):
        if self.ondown:
            if self.curcooldown==self.setcooldown:
                self.ondown=False
                self.curcooldown=0
            else:
                self.curcooldown+=1
                
            
        
class mrblob:
    def __init__(self,x,y):
        self.health=10
        self.x=x
        self.y=y
        self.px=int(x-50/50)
        self.py=int(y-50/50)
        self.nx=int(x/50)
        self.ny=int(y/50)
        self.price=50
        self.type='mrblob'
        self.vis=True
        self.damaged=False
        self.livetime=0
        self.payout=self.price*0.5

        
    def draw(self):
        win.blit(mrblobp,(self.x,self.y))
        if self.damaged:
            win.blit(damagedp,(self.x,self.y))
    def pathfind(self):
        x=int(self.x/50)
        y=int(self.y/50)
        if x>0 and x<13 and y>0 and y<13:
            
            if Grid[y][x+1]=='$' or Grid[y][x+1]=='!':
                if x+1==self.px and y==self.py:
                    pass  
                else:
                    self.nx=x+1
                    self.ny=y
                    return
            if Grid[y][x-1]=='$' or Grid[y][x-1]=='!':
                if x-1==self.px and y==self.py:
                    pass
                else:
                    self.nx=x-1
                    self.ny=y
                    return
            if Grid[y-1][x]=='$' or Grid[y-1][x]=='!':
                if x==self.px and y-1==self.py:
                    pass
                else:
                    self.nx=x
                    self.ny=y-1
                    return
            if Grid[y+1][x]=='$' or Grid[y+1][x]=='!':
                if x==self.px and y+1==self.py:
                    pass
                else:
                    self.nx=x
                    self.ny=y+1
                    return
            if Grid[y-1][x-1]=='$' or Grid[y-1][x-1]=='!':
                if x-1==self.px and y-1==self.py:
                    pass
                else:
                    self.nx=x-1
                    self.ny=y-1
                    return
            if Grid[y-1][x+1]=='$' or Grid[y-1][x+1]=='!':
                if x+1==self.px and y-1==self.py:
                    pass
                else:
                    self.nx=x+1
                    self.ny=y-1
                    return
            if Grid[y+1][x-1]=='$' or Grid[y+1][x-1]=='!':
                if x-1==self.px and y+1==self.py:
                    pass
                else:
                    self.nx=x-1
                    self.ny=y+1
                    return
            if Grid[y+1][x+1]=='$' or Grid[y+1][x+1]=='!':
                if x+1==self.px and y+1==self.py:
                    pass
                else:
                    self.nx=x+1
                    self.ny=y+1
                    return
        elif x<=0 and y>0 and y<13:
            
            if Grid[y][x+1]=='$' or Grid[y][x+1]=='!':
                if x+1==self.px and y==self.py:
                    pass
                else:
                    self.nx=x+1
                    self.ny=y
                    return
            if Grid[y-1][x]=='$' or Grid[y-1][x]=='!':
                if x==self.px and y-1==self.py:
                    pass
                else:
                    self.nx=x
                    self.ny=y-1
                    return
            if Grid[y+1][x]=='$' or Grid[y+1][x]=='!':
                if x==self.px and y+1==self.py:
                    pass
                else:
                    self.nx=x
                    self.ny=y+1
                    return
            if Grid[y-1][x+1]=='$' or Grid[y-1][x+1]=='!':
                if x+1==self.px and y-1==self.py:
                    pass
                else:
                    self.nx=x+1
                    self.ny=y-1
                    return
            if Grid[y+1][x+1]=='$' or Grid[y+1][x+1]=='!':
                if x+1==self.px and y+1==self.py:
                    pass
                else:
                    self.nx=x+1
                    self.ny=y+1
                    return
    def move(self):
        self.px=int(self.x/50)
        self.py=int(self.y/50)
        self.x=self.nx*50
        self.y=self.ny*50
        self.damaged=False
    def end(self):
        global money
        global cpu_lives
        if int(self.x/50)==0 and int(self.y/50)==1:
            money+=int(self.price*1.5)
            a=pepole.index(self)
            pepole.pop(a)
            cpu_lives-=1
        if self.health==0:
            money+=int(self.price*0.5)
            a=pepole.index(self)
            pepole.pop(a)
    def damage(self):
        self.health-=1
        self.damaged=True
        if self.health<=0:
            self.end()
        pygame.mixer.stop()
        mixer.music.load('hurt.wav')
        mixer.music.play()
        mixer.music.load('back.wav')
        mixer.music.play()
class skidy:
    def __init__(self,x,y):
        self.health=13
        
        self.x=x
        self.y=y
        self.px=int(x-50/50)
        self.py=int(y-50/50)
        self.nx=int(x/50)
        self.ny=int(y/50)
        self.price=100
        self.type='skidy'
        self.vis=True
        self.damaged=False
        self.livetime=0
        self.healtime=0
        
    def draw(self):
        win.blit(skidyp,(self.x,self.y))
        if self.damaged:
            win.blit(damagedp,(self.x,self.y))
    def pathfind(self):
        x=int(self.x/50)
        y=int(self.y/50)
        if x>0 and x<13 and y>0 and y<13:
            
            if Grid[y][x+1]=='$' or Grid[y][x+1]=='!':
                if x+1==self.px and y==self.py:
                    pass  
                else:
                    self.nx=x+1
                    self.ny=y
                    return
            if Grid[y][x-1]=='$' or Grid[y][x-1]=='!':
                if x-1==self.px and y==self.py:
                    pass
                else:
                    self.nx=x-1
                    self.ny=y
                    return
            if Grid[y-1][x]=='$' or Grid[y-1][x]=='!':
                if x==self.px and y-1==self.py:
                    pass
                else:
                    self.nx=x
                    self.ny=y-1
                    return
            if Grid[y+1][x]=='$' or Grid[y+1][x]=='!':
                if x==self.px and y+1==self.py:
                    pass
                else:
                    self.nx=x
                    self.ny=y+1
                    return
            if Grid[y-1][x-1]=='$' or Grid[y-1][x-1]=='!':
                if x-1==self.px and y-1==self.py:
                    pass
                else:
                    self.nx=x-1
                    self.ny=y-1
                    return
            if Grid[y-1][x+1]=='$' or Grid[y-1][x+1]=='!':
                if x+1==self.px and y-1==self.py:
                    pass
                else:
                    self.nx=x+1
                    self.ny=y-1
                    return
            if Grid[y+1][x-1]=='$' or Grid[y+1][x-1]=='!':
                if x-1==self.px and y+1==self.py:
                    pass
                else:
                    self.nx=x-1
                    self.ny=y+1
                    return
            if Grid[y+1][x+1]=='$' or Grid[y+1][x+1]=='!':
                if x+1==self.px and y+1==self.py:
                    pass
                else:
                    self.nx=x+1
                    self.ny=y+1
                    return
        elif x<=0 and y>0 and y<13:
            
            if Grid[y][x+1]=='$' or Grid[y][x+1]=='!':
                if x+1==self.px and y==self.py:
                    pass
                else:
                    self.nx=x+1
                    self.ny=y
                    return
            if Grid[y-1][x]=='$' or Grid[y-1][x]=='!':
                if x==self.px and y-1==self.py:
                    pass
                else:
                    self.nx=x
                    self.ny=y-1
                    return
            if Grid[y+1][x]=='$' or Grid[y+1][x]=='!':
                if x==self.px and y+1==self.py:
                    pass
                else:
                    self.nx=x
                    self.ny=y+1
                    return
            if Grid[y-1][x+1]=='$' or Grid[y-1][x+1]=='!':
                if x+1==self.px and y-1==self.py:
                    pass
                else:
                    self.nx=x+1
                    self.ny=y-1
                    return
            if Grid[y+1][x+1]=='$' or Grid[y+1][x+1]=='!':
                if x+1==self.px and y+1==self.py:
                    pass
                else:
                    self.nx=x+1
                    self.ny=y+1
                    return
    def move(self):
        self.px=int(self.x/50)
        self.py=int(self.y/50)
        self.x=self.nx*50
        self.y=self.ny*50
        self.damaged=False
    def heal(self):
        if self.health<7:
            if self.healtime>3:
                self.healtime+=1
            elif self.healtime==3:
                self.health+=1
                self.healtime=0
    def end(self):
        global money
        global cpu_lives
        if int(self.x/50)==0 and int(self.y/50)==1:
            money+=int(self.price*1.5)
            a=pepole.index(self)
            pepole.pop(a)
            cpu_lives-=1
        if self.health==0:
            money+=int(self.price*0.5)
            a=pepole.index(self)
            pepole.pop(a)
    def damage(self):
        self.health-=1
        self.damaged=True
        if self.health<=0:
            self.end()
        pygame.mixer.stop()
        mixer.music.load('hurt.wav')
        mixer.music.play()
        mixer.music.load('back.wav')
        mixer.music.play()
            
class trojanhouse:
    def __init__(self,x,y):
        self.health=5
        self.x=x
        self.y=y
        self.px=int(x-50/50)
        self.py=int(y-50/50)
        self.nx=int(x/50)
        self.ny=int(y/50)
        self.price=75
        self.type='trojan'
        self.vis=False
        self.damaged=False
        
    def draw(self):
        win.blit(trojanp,(self.x,self.y))
        if self.damaged:
            win.blit(damagedp,(self.x,self.y))
    def pathfind(self):
        x=int(self.x/50)
        y=int(self.y/50)
        if x>0 and x<13 and y>0 and y<13:
            
            if Grid[y][x+1]=='$' or Grid[y][x+1]=='!':
                if x+1==self.px and y==self.py:
                    pass  
                else:
                    self.nx=x+1
                    self.ny=y
                    return
            if Grid[y][x-1]=='$' or Grid[y][x-1]=='!':
                if x-1==self.px and y==self.py:
                    pass
                else:
                    self.nx=x-1
                    self.ny=y
                    return
            if Grid[y-1][x]=='$' or Grid[y-1][x]=='!':
                if x==self.px and y-1==self.py:
                    pass
                else:
                    self.nx=x
                    self.ny=y-1
                    return
            if Grid[y+1][x]=='$' or Grid[y+1][x]=='!':
                if x==self.px and y+1==self.py:
                    pass
                else:
                    self.nx=x
                    self.ny=y+1
                    return
            if Grid[y-1][x-1]=='$' or Grid[y-1][x-1]=='!':
                if x-1==self.px and y-1==self.py:
                    pass
                else:
                    self.nx=x-1
                    self.ny=y-1
                    return
            if Grid[y-1][x+1]=='$' or Grid[y-1][x+1]=='!':
                if x+1==self.px and y-1==self.py:
                    pass
                else:
                    self.nx=x+1
                    self.ny=y-1
                    return
            if Grid[y+1][x-1]=='$' or Grid[y+1][x-1]=='!':
                if x-1==self.px and y+1==self.py:
                    pass
                else:
                    self.nx=x-1
                    self.ny=y+1
                    return
            if Grid[y+1][x+1]=='$' or Grid[y+1][x+1]=='!':
                if x+1==self.px and y+1==self.py:
                    pass
                else:
                    self.nx=x+1
                    self.ny=y+1
                    return
        elif x<=0 and y>0 and y<13:
            
            if Grid[y][x+1]=='$' or Grid[y][x+1]=='!':
                if x+1==self.px and y==self.py:
                    pass
                else:
                    self.nx=x+1
                    self.ny=y
                    return
            if Grid[y-1][x]=='$' or Grid[y-1][x]=='!':
                if x==self.px and y-1==self.py:
                    pass
                else:
                    self.nx=x
                    self.ny=y-1
                    return
            if Grid[y+1][x]=='$' or Grid[y+1][x]=='!':
                if x==self.px and y+1==self.py:
                    pass
                else:
                    self.nx=x
                    self.ny=y+1
                    return
            if Grid[y-1][x+1]=='$' or Grid[y-1][x+1]=='!':
                if x+1==self.px and y-1==self.py:
                    pass
                else:
                    self.nx=x+1
                    self.ny=y-1
                    return
            if Grid[y+1][x+1]=='$' or Grid[y+1][x+1]=='!':
                if x+1==self.px and y+1==self.py:
                    pass
                else:
                    self.nx=x+1
                    self.ny=y+1
                    return
    def move(self):
        self.px=int(self.x/50)
        self.py=int(self.y/50)
        self.x=self.nx*50
        self.y=self.ny*50
        self.damaged=False
    def end(self):
        global money
        global cpu_lives
        if int(self.x/50)==0 and int(self.y/50)==1:
            money+=int(self.price*1.5)
            a=pepole.index(self)
            pepole.pop(a)
            cpu_lives-=1
        if self.health==0:
            money+=int(self.price*0.5)
            a=pepole.index(self)
            pepole.pop(a)
    def damage(self):
        self.health-=1
        self.damaged=True
        pygame.mixer.stop()
        mixer.music.load('hurt.wav')
        mixer.music.play()
        mixer.music.load('back.wav')
        mixer.music.play()
    
        
            
            
        
#virus menu
menfont=pygame.font.SysFont('times new roman',20)
bigfont=pygame.font.SysFont('times new roman',50)

class buy_button:
    global money
    global pepole
    def __init__(self,name,x,y,pic,price):
        self.name=name
        self.x=x
        self.y=y
        self.pic=pygame.image.load(pic)
        self.price=price
        self.clicked=False
        
    def draw(self):
        pygame.draw.rect(win,(200,155,100),(self.x,self.y,100,100))
        name=menfont.render(f'{self.name}',True,(0,0,0))
        win.blit(name,(self.x,self.y))
        win.blit(self.pic,(self.x+25,self.y+20))
        price=menfont.render(f'cost:{self.price}',True,(0,0,0))
        win.blit(price,(self.x+10,self.y+70))
    def onclick(self):
        global money
        global pepole
        mx,my=pygame.mouse.get_pos()
        if mx>=self.x and mx<=self.x+100 and my>=self.y and my<=self.y+100 and not self.clicked:
            if pygame.mouse.get_pressed()[0]:
                if money>=self.price:
                    if len(pepole)>0:
                        if pepole[0].x!=0 and pepole[0].y!=550:
                            money-=self.price
                            self.clicked=True
                            return True
                    else:
                        money-=self.price
                        self.clicked=True
                        return True
        if not pygame.mouse.get_pressed()[0]:
            self.clicked=False
        return False
                
        
mrblobb=buy_button('mr.blob',710,70,'mrblobp.png',50,)
trojanb=buy_button('trojan house',710,190,'trojanp.png',75,)
skidyb=buy_button('skidy',710,310,'skidyp.png',100,)

def drawvimen():
    pygame.draw.rect(win,(150,255,150),(700,0,200,700))
    mentitle=menfont.render(f'virus menu',True,(0,0,0))
    win.blit(mentitle,(750,5))
    pygame.draw.line(win,(0,0,0),(705,25),(895,25),3)
    text=menfont.render(f'money:{money}',True,(0,0,0))
    win.blit(text,(710,40))
    mrblobb.draw()
    if mrblobb.onclick():
        pepole.append(mrblob(0,550))
    trojanb.draw()
    if trojanb.onclick():
        pepole.append(trojanhouse(0,550))
    skidyb.draw()
    if skidyb.onclick():
        pepole.append(skidy(0,550))
def runviruses():
    global pepole
    global sectime
    if sectime==30 or sectime==60:
        for per in pepole:
            
            per.pathfind()
            per.move()
            per.draw()
            per.end()
            if sectime==60 and per.type=='skidy':
                per.heal()
            
    else:
        for per in pepole:
            per.draw()
            
    pygame.display.update()
#_______________________________________
def runtowers():
    global towers
    global sectime
    if sectime==30 or sectime==60:
        for tow in towers:
            tow.cooldown()
            tow.scan()
            
    
def copy(lis):
    a=[]
    for thing in lis:
        a.append(thing)
    return a
def actpgrid():
    a=copy(Grid)
    for row in range(14):
        for col in range(14):
            if Grid[row][col]=='$' or Grid[row][col]=='@' or Grid[row][col]=='!':
                pass
            else:
               
                if row==0 or row==13 or col==0 or col==13:
                    pass
                else:
                    
                    if Grid[row-1][col]=='$' or Grid[row+1][col]=='$':
                        a[row][col]='*'
                        
                    elif Grid[row][col-1]=='$' or Grid[row][col+1]=='$':
                        a[row][col]='*'
                    
    return a
                
pgrid=actpgrid()
def place_towers():
    global towers 
    towernum=15
    for row in range(14):
        for col in range(14):
            if towernum==0:
                return
            if pgrid[row][col]=='*':
                b=random.randint(0,15)
                if b<=(15-towernum):
                    pass
                else:
                    b=random.randint(1,3)
                    
                    if not b==1:
                        if b==2:
                            towers.append(fireshot(col*50,row*50))
                        if b==3:
                            towers.append(virusscan(col*50,row*50))
                        pgrid[row][col]=str(b-1)
                        towernum-=1

def drawgrid():
    for i in range(13):
            pygame.draw.line(win,(255,255,255),(0,i*50+50),(700,i*50+50),1)
    for i in range(13):
            pygame.draw.line(win,(255,255,255),(i*50+50,0),(i*50+50,700),1)
            
path=pygame.image.load('path.png')
tile=pygame.image.load('tile.png')
cpu=pygame.image.load('cpu.png')
usb=pygame.image.load('usb.png')
def draw():
    for row in range(14):
        for col in range(14):
            if Grid[row][col]=='#':
                win.blit(tile,(col*50,row*50,))
            if Grid[row][col]=='$':
                win.blit(path,(col*50,row*50,))
            if Grid[row][col]=='!':
                win.blit(cpu,(col*50,row*50,))
            if Grid[row][col]=='@':
                win.blit(usb,(col*50,row*50,))
            if Grid[row][col]=='*':
                win.blit(tile,(col*50,row*50,))
    for row in range(14):
        for col in range(14):
            if pgrid[row][col]=='1':
                win.blit(fireshotp,(col*50,row*50))
            if pgrid[row][col]=='2':
                pygame.draw.rect(win,(0,255,0),(col*50,row*50,50,50))
                win.blit(virusscanp,(col*50,row*50))
            if pgrid[row][col]=='3':
                pygame.draw.rect(win,(255,0,0),(col*50,row*50,50,50))
def endgame(wi):
    if wi:
        endmes=bigfont.render('you win the cpu is compotly destryed',True,(0,0,0)) 
        win.blit(endmes,(50,300))
        pygame.display.update()
        time.sleep(5)
        startmen()
    if not wi:
        endmes=bigfont.render('you losue you faid and ran out of money',True,(0,0,0)) 
        win.blit(endmes,(50,300))
        pygame.display.update()
        time.sleep(5)
        startmen()
    
def main():
    mixer.music.load('back.wav')
    mixer.music.play()
    global sectime
    global money
    global pepole
    global towers
    global cpu_lives
    sectime=0
    money=200
    pepole=[]
    towers=[]
    cpu_lives=20
    Grid=[['#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#'],
    ['!', '$', '$', '$', '$', '$', '$', '$', '$', '$', '$', '$', '$', '#'],
    ['#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '$', '#'],
    ['#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '$', '#'],
    ['#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '$', '#'],
    ['#', '$', '$', '$', '$', '$', '$', '$', '$', '$', '#', '#', '$', '#'],
    ['#', '$', '#', '#', '#', '#', '#', '#', '#', '$', '#', '#', '$', '#'],
    ['#', '$', '#', '#', '#', '#', '#', '#', '#', '$', '#', '#', '$', '#'],
    ['#', '$', '$', '$', '$', '$', '$', '$', '#', '$', '#', '#', '$', '#'],
    ['#', '#', '#', '#', '#', '#', '#', '$', '#', '$', '#', '#', '$', '#'],
    ['#', '#', '#', '#', '#', '#', '#', '$', '#', '$', '#', '#', '$', '#'],
    ['@', '$', '$', '$', '#', '#', '#', '$', '#', '$', '#', '#', '$', '#'],
    ['#', '#', '#', '$', '$', '$', '$', '$', '#', '$', '$', '$', '$', '#'],
    ['#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#']]
    place_towers()
    while True:
        cpul=menfont.render(f'cpu_lives:{cpu_lives}',True,(0,0,0))
        for event in pygame.event.get():
            if event.type==pygame.QUIT:
                pygame.quit()
                sys.exit()
        win.fill((0,0,0))
        draw()
        #drawgrid()
        drawvimen()
        win.blit(cpul,(10,10))
        runviruses()
        runtowers()
        pygame.display.update()
        clock.tick(60)
        sectime+=1
        if sectime>60:
            sectime=0
        if cpu_lives==0:
            pygame.mixer.stop()
            endgame(True)
        if len(pepole)==0 and money<50:
            pygame.mixer.stop()
            endgame(False)
def credits():
    mixer.music.load('back.wav')
    mixer.music.play()
    while True:
        mx,my=pygame.mouse.get_pos()
        for event in pygame.event.get():
            if event.type==pygame.QUIT:
                pygame.quit()
                sys.exit()
        win.fill((0,0,0))
        pygame.draw.rect(win,(255,0,0),(675,580,200,100))
        c=bigfont.render('Credits',True,(255,255,255))
        win.blit(c,(370,10))
        c1=menfont.render('lead develpor:Trystan wipf',True,(255,255,255))
        win.blit(c1,(350,100))
        c2=menfont.render('lead desiner:Trystan wipf',True,(255,255,255))
        c3=menfont.render('lead artest:Trystan wipf',True,(255,255,255))
        win.blit(c3,(350,150))
        win.blit(c2,(350,200))
        c1=menfont.render('art team:Trystan wipf,Cole Bevan',True,(255,255,255))
        win.blit(c1,(350,250))
        c3=menfont.render('lead sound dezinger:Trystan wipf',True,(255,255,255))
        win.blit(c3,(350,300))
        qu=bigfont.render('back',True,(0,0,0))
        win.blit(qu,(725,600))
        pygame.display.update()
        if mx>=675 and mx<=855 and my>=580 and my<=680:
            if pygame.mouse.get_pressed()[0]:
                startmen()
def helpm():
    mixer.music.load('back.wav')
    mixer.music.play()
    pic=pygame.image.load('totwin.png')
    pic=pygame.transform.scale(pic,(300,300))
    while True:
        mx,my=pygame.mouse.get_pos()
        for event in pygame.event.get():
            if event.type==pygame.QUIT:
                pygame.quit()
                sys.exit()
        win.fill((0,255,0))
        win.blit(pic,(50,50))
        title=bigfont.render('Help',True,(0,0,0))
        win.blit(title,(350,25))
        h1=menfont.render('welcome to cyber tower attack a revers tower defence game were you send viruses throught a randomly',True,(0,0,0))
        win.blit(h1,(5,350))
        h2=menfont.render('generated path of anti-viruse software in a atempt to harm and completly destroy the cpu without runing out of /n money',True,(0,0,0))
        win.blit(h2,(5,370))
        h3=menfont.render('money',True,(0,0,0))
        win.blit(h3,(5,390))
        h4=bigfont.render('viruses',True,(0,0,0))
        win.blit(h4,(5,410))
        h2=menfont.render('Mr.Blob: mr.blob is just a basic viruse costing 50 money and haveing 10 lives with no special abilitys',True,(0,0,0))
        win.blit(h2,(5,460))
        h2=menfont.render('trojan house: the trojan house is 75 money and has 5 lives but he is able to sneak past sertan towers',True,(0,0,0))
        win.blit(h2,(5,480))
        h2=menfont.render('skidy: skidy is 100 money and has 13 lives but he is able to regenerate lives evry 3 secondes to a max of 7 lives',True,(0,0,0))
        win.blit(h2,(5,500))
        h4=bigfont.render('Towers',True,(0,0,0))
        win.blit(h4,(5,530))
        h2=menfont.render('Firewall: firewall is a basic tower with a 3 second cooldown between attacks',True,(0,0,0))
        win.blit(h2,(5,580))
        h2=menfont.render('viruse scan: virus scan is a tower theat has a 7 second cooldown with the special abliity to see',True,(0,0,0))
        win.blit(h2,(5,600))
        h2=menfont.render('invisable viruses(the trojan house)',True,(0,0,0))
        win.blit(h2,(355,620))
        pygame.draw.rect(win,(255,255,255),(750,650,100,50))
        help=menfont.render('back',True,(0,0,0))
        win.blit(help,(750,650))
        pygame.display.update()
        if mx>=750 and mx<=850 and my>=650 and my<=700:
            if pygame.mouse.get_pressed()[0]:
                pygame.mixer.stop()
                startmen()
def startmen():
    page=pygame.image.load('titlepage.png')
    
    mixer.music.load('back.wav')
    mixer.music.play()
    while True:
        mx,my=pygame.mouse.get_pos()
        for event in pygame.event.get():
            if event.type==pygame.QUIT:
                pygame.quit()
                sys.exit()
        win.fill((0,255,0))
        win.blit(page,(60,0))
        title=bigfont.render('cyber tower attack',True,(0,0,0))
        win.blit(title,(300,50))
        pygame.draw.rect(win,(200,255,100),(350,300,200,100))
        go=bigfont.render('start',True,(0,0,0))
        win.blit(go,(410,320))
        pygame.draw.rect(win,(100,100,100),(350,430,200,100))
        cred=bigfont.render('credits',True,(0,0,0))
        win.blit(cred,(380,450))
        pygame.draw.rect(win,(255,0,0),(350,560,200,100))
        qu=bigfont.render('quit',True,(0,0,0))
        win.blit(qu,(410,580))
        pygame.draw.rect(win,(255,255,255),(10,10,20,20))
        help=menfont.render('?',True,(0,0,0))
        win.blit(help,(15,10))
        pygame.display.update()
        if mx>=10 and mx<=30 and my>=10 and my<=30:
            if pygame.mouse.get_pressed()[0]:
                pygame.mixer.stop()
                helpm()
        pygame.display.update()
        if mx>=350 and mx<=550 and my>=300 and my<=400:
            if pygame.mouse.get_pressed()[0]:
                pygame.mixer.stop()
                main()
        if mx>=350 and mx<=550 and my>=430 and my<=530:
            if pygame.mouse.get_pressed()[0]:
                pygame.mixer.stop()
                credits()
        if mx>=350 and mx<=550 and my>=560 and my<=660:
            if pygame.mouse.get_pressed()[0]:
                pygame.mixer.stop()
                pygame.quit()
                sys.exit()
startmen()    

